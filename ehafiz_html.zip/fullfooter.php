<div class="section">
       <div class="horizontal-scrolling">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <h2 class="footer-heading">Our Reach</h2>
                    <div class="contry_flags">
                        <ul>
                            <li><a href="#"><span class="flag-icon flag-icon-af"></span>Afganistan</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-al"></span>Albania</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-dz"></span>Albania</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-as"></span>American Samoa</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-bw"></span>Andorra</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-ao"></span>Angola</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-ai"></span>Anguilla</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-ag"></span>Antigua and Barbuda</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-ar"></span>Argentina</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-am"></span>Armenia</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-aw"></span>Aruba</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-au"></span>Australia</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-at"></span>Austria</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-az"></span>Azerbaijan</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-bs"></span>Bahamas</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-bh"></span>Bahrain</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-bd"></span>Bangladesh</a></li>
                            
                        </ul>
                        <ul class="bottom">
                            <li><a href="#"><span class="flag-icon flag-icon-bb"></span>Barbados</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-by"></span>Belarus</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-bz"></span>Belize</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-be"></span>Belgium</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-bj"></span>Benin</a></li>
                             <li><a href="#"><span class="flag-icon flag-icon-bm"></span>Bermuda</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-bt"></span>Bhutan</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-bo"></span>Bolivia</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-ba"></span>Bosnia and Herzegovina</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-bw"></span>Botswana</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-br"></span>Brazil</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-vg"></span>Virgin Islands</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-bn"></span> Brunei Darussalam</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-bg"></span>Bulgaria</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-bf"></span>Burkina Faso</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-mm"></span>Myanmar</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-bi"></span>Burundi</a></li>
                            
                        </ul>
                        <ul>
                            <li><a href="#"><span class="flag-icon flag-icon-kh"></span>Cambodia</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-cm"></span>Cameroon</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-ca"></span>Canada</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-cv"></span>Cabo Verde</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-ky"></span>Cayman Islands</a></li>
                             <li><a href="#"><span class="flag-icon flag-icon-cf"></span>Central African Republic</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-td"></span>Chad</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-cl"></span>Chile</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-cn"></span>China</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-cc"></span>Cocos (Keeling) Islands</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-km"></span>Comoros</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-co"></span>Colombia</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-cd"></span>Democratic Republic of the Congo</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-ck"></span>Cook Islands</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-cr"></span> Costa Rica</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-ci"></span>Côte d'Ivoire</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-hr"></span>Croatia</a></li>
                        </ul>
                        <ul>
                            <li><a href="#"><span class="flag-icon flag-icon-cy"></span>Cyprus</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-cz"></span>Czech Republic</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-dk"></span>Denmark</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-dj"></span>Djibouti</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-dm"></span>Dominica</a></li>
                             <li><a href="#"><span class="flag-icon flag-icon-do"></span>Dominican Republic</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-ec"></span>Ecuador</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-eg"></span>Egypt</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-sv"></span>Ei Salvador</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-gq"></span>Equatorial Guinea</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-er"></span>Eritrea</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-ee"></span>Estonia</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-et"></span>Ethiopia</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-fo"></span>Faroe Islands</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-fk"></span>Falkland Islands</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-fr"></span>France</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-fj"></span>Fiji</a></li>
                            
                        </ul>
                        <ul>
                            <li><a href="#"><span class="flag-icon flag-icon-ng"></span>Nigeria</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-qa"></span>Qatar</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-kp"></span>North Korea</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-mk"></span>North Macedonia</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-mp"></span>Northern Mariana Islands</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-no"></span>Norway</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-om"></span>Oman</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-pk"></span>Pakistan</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-pw"></span>Palau</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-ps"></span>State of Palestine</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-pa"></span>Panama</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-pg"></span>Papua New Guinea</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-py"></span>Paraguay</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-pe"></span>Peru</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-ph"></span>Philippines</a></li>
                            <li><a href="#"><span class="flag-icon flag-icon-pl"></span>Poland</a></li>
                           
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <?php include 'footer.php';?>
    </div>
       <div class="horizontal-scrolling">
        <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                       <div class="conatiner box">
        	<h2 class="contact"> Contact us</h2>
        	<div class="hr">
        		
        	</div>


    <input type="text" placeholder="Your name" name="email" required class="name">
    <input type="text" placeholder="Your Email" name="email" required class="email">
    <textarea name="your-message" placeholder="Message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea form-control" id="contact-message" aria-invalid="false"></textarea>
    <button class="submit"> Submit</button>
        </div> 
                    </div>
                </div>
            </div>
            <?php include 'footer.php';?>
    </div>
</div>