<div class="bottom_footer">
            <div class="container">
                <div class="row">
                   <div class="col-sm-12">
                       <div class="last_samuray">
                       <ul>
                        <li>&copy; Copyright 2019, e-Hafiz. All rights reserved.</li>
                    </ul>
                    <ul>
                        <li>Design by Clamour Technologies</li>
                    </ul>
                    <ul class="social_icon_footer">
                           <li>Get to touch</li>
                            <li><a href=""><i class="fab fa-facebook-square"></i></a></li>
                            <li><a href=""><i class="fab fa-instagram"></i></a></li>
                            <li><a href=""><i class="fab fa-youtube-square"></i></a></li>
                            <li><a href=""><i class="fab fa-twitter-square"></i></a></li>
                            <li><a href=""><i class="fab fa-whatsapp-square"></i></a></li>
                        </ul>
                   </div>
                   </div>
                </div>
            </div>
        </div>