<!--Top Heade Section Start-->
<section class="top-header">
    <div class="container">
        <ul>
            <li><a href="javascript:;"> <i class="fal fa-phone-alt"></i> +91 6301 671 634</a></li>
            <li>
            <a href="#" data-toggle="modal" data-target="#loginOPtion">LOGIN</a>

<!-- Modal -->
<div class="modal fade" id="loginOPtion" tabindex="-1" role="dialog" aria-labelledby="loginOPtionTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="loginOPtionTitle">Login Option</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <ul class="login_Option">
            <li><a href="login_female.php"><img src="img/Login/fermale.png" alt=""> Female Login</a></li>
            <li><a href="login_male.php"><img src="img/Login/male.png" alt=""> Male Login</a></li>
        </ul>
      </div>
      <!--<div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>-->
    </div>
  </div>
</div>
            
            </li>
            <li><a href="register.php">REGISTRATION</a></li>
        </ul>
    </div>
</section>
<!--Top Heade Section End-->

<!--Navbar Section Start-->
<section class="ehafiz_nav">
    <nav class="navbar sticky-top navbar-expand-md">
      <div class="container">
          <a class="navbar-brand ehafiz_logo" href="index.php">
          <img src="img/Logo.png" alt=""></a>
    <div class="hamburger collapsed" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <div class="hamburger__container">
      <div class="hamburger__inner"></div>
      <div class="hamburger__hidden"></div>
    </div>
  </div>
  <div class="navbar-collapse justify-content-end collapse" id="navbarNavDropdown" style="">
    <ul class="navbar-nav custom_NavBar">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="about.php">About Us</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="features.php">Product Features</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="weworks.php">How it Works</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="contact_page.php">Contact us</a>
      </li>
      <!--<li class="nav-item">-->
      <!--  <a class="nav-link" href="https://ehafiz.world/blog/blog/">Blog</a>-->
      <!--</li>-->
      <!--<li class="nav-item">-->
      <!--  <a class="nav-link" href="https://ehafiz.world/blog/newevents/">News &amp; Media</a>-->
      <!--</li>-->
    </ul>
  </div>
      </div>
</nav>
</section>
<!--Navbar Section End-->