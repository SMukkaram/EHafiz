<div class="section">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-12">
                    <div class="contact__left">
                        <h2>Learn Online Quran</h2>
                        <h3>How Can We Help?</h3>
                        <p>We're here to help and answer any question you might have. We look forward to hearing from you.</p>
                        <img src="img/girl.jpg" class="bg_QuickconT" alt="">
                    </div>
                </div>
                <div class="col-md-6 col-sm-12">
                    <div class="conatiner box">
        	<h2 class="contact"> Contact us</h2>
        	<div class="hr">
        		
        	</div>


    <input type="text" placeholder="Your name" name="email" required class="salam_name">
    <input type="text" placeholder="Your Email" name="email" required class="salam_email">
    <input type="text" placeholder="Your Mobile Number" name="mobile" required class="salam_email">
    <textarea name="your-message" placeholder="Message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea form-control" id="salam_area" aria-invalid="false"></textarea>
    <button class="submit"> Submit</button>
        </div>
                </div>
            </div>
        </div>
    </div>
  